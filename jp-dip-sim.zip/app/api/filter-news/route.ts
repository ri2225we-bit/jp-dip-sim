import { NextResponse } from "next/server";
import { alpacaFetch } from "@/lib/alpaca";

const NEWS_BASE = "https://data.alpaca.markets/v1beta1/news";
const NEG_KEYWORDS = [
  "sec investigation","fraud","accounting","restatement","going concern",
  "guidance cut","outlook cut","downgrade","credit watch","liquidity crisis",
  "chapter 11","bankruptcy","layoffs","data breach","class action"
];

export async function POST(req: Request) {
  const { symbols } = await req.json() as { symbols: string[] };
  if (!symbols || symbols.length === 0) return NextResponse.json({ exclude: [] });

  const params = new URLSearchParams({ symbols: symbols.join(","), limit: "3", sort: "desc" });
  const r = await alpacaFetch(`${NEWS_BASE}?${params.toString()}`);
  const news = await r.json();

  const items = (news.items ?? news.news ?? []) as any[];
  const bad = new Set<string>();
  for (const n of items) {
    const sym = n.symbol || n.symbols?.[0];
    const txt = `${n.headline ?? ""} ${n.summary ?? ""}`.toLowerCase();
    if (NEG_KEYWORDS.some(k => txt.includes(k))) bad.add(sym);
  }
  return NextResponse.json({ exclude: Array.from(bad) });
}
