import { NextResponse } from "next/server";
import { alpacaFetch } from "@/lib/alpaca";

const DATA_BASE = "https://data.alpaca.markets/v2";

export const revalidate = 0; // always fresh

export async function GET() {
  // 1) active equities
  const assetsRes = await fetch("https://paper-api.alpaca.markets/v2/assets?status=active&asset_class=us_equity", {
    headers: {
      "APCA-API-KEY-ID": process.env.ALPACA_KEY || "",
      "APCA-API-SECRET-KEY": process.env.ALPACA_SECRET || ""
    }
  });
  const assets = await assetsRes.json();
  const symbols: string[] = (assets || []).slice(0, 300).map((a:any)=>a.symbol);

  if (symbols.length === 0) return NextResponse.json([]);

  // 2) recent 2 daily bars per symbol
  const since = new Date(Date.now() - 3*24*3600*1000).toISOString();
  const url = `${DATA_BASE}/stocks/bars?timeframe=1Day&symbols=${symbols.join(",")}&limit=2&start=${since}`;
  const barsRes = await alpacaFetch(url);
  const bars = await barsRes.json();

  const rows: any[] = [];
  for (const sym of Object.keys(bars.bars || {})) {
    const arr = bars.bars[sym];
    if (!arr || arr.length < 2) continue;
    const prevClose = arr[arr.length-2].c;
    const last = arr[arr.length-1].c;
    const pct = ((last - prevClose)/prevClose)*100;
    rows.push({ symbol: sym, pct: Number(pct.toFixed(2)), last, prevClose });
  }

  rows.sort((a,b)=>a.pct - b.pct);

  // 3) Basic liquidity/price filter
  const filtered = rows.filter(r => r.last > 2).slice(0, 50);
  return NextResponse.json(filtered);
}
