import { NextResponse } from "next/server";

const TRADING = "https://paper-api.alpaca.markets/v2/orders";

export async function POST(req: Request) {
  const body = await req.json() as { symbol: string; qty: number; side: "buy"|"sell" };
  const r = await fetch(TRADING, {
    method: "POST",
    headers: {
      "APCA-API-KEY-ID": process.env.ALPACA_KEY || "",
      "APCA-API-SECRET-KEY": process.env.ALPACA_SECRET || "",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      symbol: body.symbol,
      qty: body.qty,
      side: body.side,
      type: "market",
      time_in_force: "day"
    })
  });
  const out = await r.json();
  return NextResponse.json(out);
}
