const KEY = process.env.ALPACA_KEY ?? "";
const SECRET = process.env.ALPACA_SECRET ?? "";

export async function alpacaFetch(url: string, init: RequestInit = {}) {
  const headers = {
    ...(init.headers || {}),
    "APCA-API-KEY-ID": KEY,
    "APCA-API-SECRET-KEY": SECRET,
  } as Record<string,string>;
  return fetch(url, { ...init, headers });
}
